package com.editioncup.data.model

import java.util.UUID

/**
 * Modelos de dados não-destrutivos da linha do tempo.
 * Toda edição é feita sobre referências e offsets, nunca alterando o arquivo original.
 */

enum class TrackType {
    VIDEO,
    AUDIO,
    TEXT,
    OVERLAY,   // imagens, adesivos, picture-in-picture
    EFFECT
}

data class MediaItem(
    val id: String = UUID.randomUUID().toString(),
    val uri: String,
    val displayName: String,
    val durationMs: Long,
    val width: Int = 0,
    val height: Int = 0,
    val mimeType: String = "",
    val hasAudio: Boolean = true,
    val frameRate: Float = 30f
)

/**
 * Um clipe na timeline. Referência ao MediaItem + offsets de início/fim.
 */
data class TimelineClip(
    val id: String = UUID.randomUUID().toString(),
    val mediaId: String,
    val trackId: String,
    /** Posição de início na timeline (ms) */
    val startTimeMs: Long,
    /** Duração do clipe na timeline (ms) */
    val durationMs: Long,
    /** Offset de início dentro do arquivo de mídia original (ms) */
    val sourceStartMs: Long = 0L,
    /** Offset de fim dentro do arquivo original (ms) – null = até o fim */
    val sourceEndMs: Long? = null,

    // Transformações
    val speed: Float = 1.0f,
    val volume: Float = 1.0f,
    val opacity: Float = 1.0f,
    val rotation: Float = 0f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val translateX: Float = 0f,
    val translateY: Float = 0f,
    val mirrorHorizontal: Boolean = false,
    val mirrorVertical: Boolean = false,

    // Estado
    val isLocked: Boolean = false,
    val isMuted: Boolean = false,
    val isHidden: Boolean = false
) {
    val endTimeMs: Long get() = startTimeMs + durationMs
}

data class TimelineTrack(
    val id: String = UUID.randomUUID().toString(),
    val type: TrackType,
    val name: String,
    val order: Int,
    val isLocked: Boolean = false,
    val isMuted: Boolean = false,
    val isHidden: Boolean = false,
    val volume: Float = 1.0f
)

/**
 * Projeto completo.
 */
data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val durationMs: Long = 0L,
    val width: Int = 1920,
    val height: Int = 1080,
    val frameRate: Int = 60,
    val tracks: List<TimelineTrack> = emptyList(),
    val clips: List<TimelineClip> = emptyList(),
    val mediaLibrary: List<MediaItem> = emptyList()
)

/**
 * Configurações de exportação.
 */
data class ExportSettings(
    val width: Int = 1920,
    val height: Int = 1080,
    val frameRate: Int = 60,
    val bitrateMbps: Float = 12f,
    val videoCodec: VideoCodec = VideoCodec.H264,
    val audioCodec: AudioCodec = AudioCodec.AAC,
    val audioBitrateKbps: Int = 192,
    val outputUri: String? = null
)

enum class VideoCodec {
    H264, H265
}

enum class AudioCodec {
    AAC, MP3
}

/**
 * Estado de undo/redo.
 */
data class EditAction(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val description: String,
    val previousState: Project,
    val newState: Project
)
