package com.editioncup

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.editioncup.ui.navigation.EditionCupNavHost
import com.editioncup.ui.theme.EditionCupTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EditionCupTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    EditionCupNavHost()
                }
            }
        }
    }
}
