package com.editioncup.domain.export

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.editioncup.data.model.ExportSettings
import com.editioncup.data.model.Project
import com.editioncup.data.model.VideoCodec
import kotlinx.coroutines.suspendCancellableCoroutine
import timber.log.Timber
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Exportação usando Media3 Transformer.
 * Versão inicial: exporta o primeiro clipe de vídeo encontrado.
 * Futuro: compor toda a timeline (múltiplas faixas, efeitos, etc.).
 */
class ExportManager(private val context: Context) {

    suspend fun export(
        project: Project,
        settings: ExportSettings,
        outputUri: Uri,
        onProgress: (Float) -> Unit = {}
    ): Result<Uri> = suspendCancellableCoroutine { cont ->

        val firstVideoClip = project.clips
            .firstOrNull { clip ->
                project.tracks.find { it.id == clip.trackId }?.type ==
                        com.editioncup.data.model.TrackType.VIDEO
            }

        if (firstVideoClip == null) {
            cont.resume(Result.failure(IllegalStateException("Nenhum clipe de vídeo no projeto")))
            return@suspendCancellableCoroutine
        }

        val media = project.mediaLibrary.find { it.id == firstVideoClip.mediaId }
        if (media == null) {
            cont.resume(Result.failure(IllegalStateException("Mídia não encontrada")))
            return@suspendCancellableCoroutine
        }

        val mediaItem = MediaItem.fromUri(media.uri)
        val editedMediaItem = EditedMediaItem.Builder(mediaItem).build()
        val sequence = EditedMediaItemSequence(listOf(editedMediaItem))
        val composition = Composition.Builder(listOf(sequence)).build()

        val transformerBuilder = Transformer.Builder(context)
            .setVideoMimeType(
                when (settings.videoCodec) {
                    VideoCodec.H265 -> MimeTypes.VIDEO_H265
                    else -> MimeTypes.VIDEO_H264
                }
            )
            .setAudioMimeType(MimeTypes.AUDIO_AAC)

        val transformer = transformerBuilder.build()

        transformer.addListener(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                Timber.i("Exportação concluída: $outputUri")
                cont.resume(Result.success(outputUri))
            }

            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                Timber.e(exportException, "Erro na exportação")
                cont.resume(Result.failure(exportException))
            }
        })

        try {
            transformer.start(composition, outputUri.toString())
        } catch (e: Exception) {
            cont.resumeWithException(e)
        }

        cont.invokeOnCancellation {
            transformer.cancel()
        }
    }
}
