package com.editioncup.domain.export

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.editioncup.R

/**
 * Serviço de primeiro plano para exportação longa.
 * Implementação mínima – será expandida com WorkManager + progress real.
 */
class ExportForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "edition_cup_export"
        const val NOTIFICATION_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification(0)
        startForeground(NOTIFICATION_ID, notification)
        // TODO: iniciar Transformer real e atualizar progresso
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Exportação de vídeo",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Progresso da exportação do Edition Cup"
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(progress: Int): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.export_in_progress))
            .setContentText("$progress%")
            .setSmallIcon(android.R.drawable.ic_menu_upload)
            .setProgress(100, progress, progress == 0)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }
}
