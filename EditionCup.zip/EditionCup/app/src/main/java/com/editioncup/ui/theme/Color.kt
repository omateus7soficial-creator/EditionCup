package com.editioncup.ui.theme

import androidx.compose.ui.graphics.Color

// Tema escuro elegante – roxo, azul e branco
val PurplePrimary = Color(0xFF9B59FF)
val PurpleDark = Color(0xFF6B2FCC)
val BlueAccent = Color(0xFF3D9BFF)
val BlueDark = Color(0xFF1A6FCC)

val BackgroundDark = Color(0xFF0D0D12)
val SurfaceDark = Color(0xFF16161F)
val SurfaceVariant = Color(0xFF1E1E2A)
val OnSurface = Color(0xFFF5F5F7)
val OnSurfaceVariant = Color(0xFFB0B0C0)

val TimelineTrackVideo = Color(0xFF4A90D9)
val TimelineTrackAudio = Color(0xFF50C878)
val TimelineTrackText = Color(0xFFE8A838)
val TimelineTrackOverlay = Color(0xFFC77DFF)

val ErrorRed = Color(0xFFFF4D6A)
val SuccessGreen = Color(0xFF2ECC71)
