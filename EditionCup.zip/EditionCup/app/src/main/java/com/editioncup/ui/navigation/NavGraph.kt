package com.editioncup.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.editioncup.ui.screens.editor.EditorScreen
import com.editioncup.ui.screens.export.ExportScreen
import com.editioncup.ui.screens.home.HomeScreen
import com.editioncup.ui.screens.settings.SettingsScreen

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Editor : Screen("editor/{projectId}") {
        fun createRoute(projectId: String) = "editor/$projectId"
    }
    data object Export : Screen("export/{projectId}") {
        fun createRoute(projectId: String) = "export/$projectId"
    }
    data object Settings : Screen("settings")
}

@Composable
fun EditionCupNavHost(
    navController: NavHostController = rememberNavController()
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                onNewProject = { projectId ->
                    navController.navigate(Screen.Editor.createRoute(projectId))
                },
                onOpenProject = { projectId ->
                    navController.navigate(Screen.Editor.createRoute(projectId))
                },
                onSettings = {
                    navController.navigate(Screen.Settings.route)
                }
            )
        }

        composable(Screen.Editor.route) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getString("projectId") ?: "new"
            EditorScreen(
                projectId = projectId,
                onBack = { navController.popBackStack() },
                onExport = {
                    navController.navigate(Screen.Export.createRoute(projectId))
                }
            )
        }

        composable(Screen.Export.route) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getString("projectId") ?: ""
            ExportScreen(
                projectId = projectId,
                onBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }
    }
}
