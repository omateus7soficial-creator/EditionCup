package com.editioncup

import android.app.Application
import timber.log.Timber

class EditionCupApp : Application() {
    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
        Timber.i("Edition Cup iniciado – Android 15+ (API 35)")
    }
}
