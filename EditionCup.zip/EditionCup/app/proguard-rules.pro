# Edition Cup - ProGuard rules
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Keep data models used by serialization if added later
-keepclassmembers class com.editioncup.data.model.** { *; }
