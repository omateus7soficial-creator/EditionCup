package com.editioncup.domain.timeline

import com.editioncup.data.model.EditAction
import com.editioncup.data.model.Project
import java.util.LinkedList

/**
 * Gerenciador simples de histórico de edição (undo/redo).
 * Mantém um número limitado de estados para não consumir muita memória.
 */
class UndoRedoManager(private val maxHistory: Int = 50) {

    private val undoStack = LinkedList<EditAction>()
    private val redoStack = LinkedList<EditAction>()

    fun push(previous: Project, current: Project, description: String) {
        undoStack.addLast(
            EditAction(
                description = description,
                previousState = previous,
                newState = current
            )
        )
        if (undoStack.size > maxHistory) {
            undoStack.removeFirst()
        }
        redoStack.clear()
    }

    fun canUndo(): Boolean = undoStack.isNotEmpty()
    fun canRedo(): Boolean = redoStack.isNotEmpty()

    fun undo(current: Project): Project? {
        if (undoStack.isEmpty()) return null
        val action = undoStack.removeLast()
        redoStack.addLast(action)
        return action.previousState
    }

    fun redo(current: Project): Project? {
        if (redoStack.isEmpty()) return null
        val action = redoStack.removeLast()
        undoStack.addLast(action)
        return action.newState
    }

    fun clear() {
        undoStack.clear()
        redoStack.clear()
    }
}
