package com.editioncup.domain.timeline

import com.editioncup.data.model.*
import java.util.UUID

/**
 * Motor da linha do tempo – operações não-destrutivas.
 * Toda alteração gera um novo estado de Project (imutabilidade).
 */
class TimelineEngine {

    fun createEmptyProject(name: String = "Projeto sem título"): Project {
        val videoTrack = TimelineTrack(
            id = UUID.randomUUID().toString(),
            type = TrackType.VIDEO,
            name = "Vídeo 1",
            order = 0
        )
        val audioTrack = TimelineTrack(
            id = UUID.randomUUID().toString(),
            type = TrackType.AUDIO,
            name = "Áudio 1",
            order = 1
        )
        return Project(
            name = name,
            tracks = listOf(videoTrack, audioTrack)
        )
    }

    fun addMediaToLibrary(project: Project, media: MediaItem): Project {
        if (project.mediaLibrary.any { it.id == media.id }) return project
        return project.copy(
            mediaLibrary = project.mediaLibrary + media,
            updatedAt = System.currentTimeMillis()
        )
    }

    fun addClip(
        project: Project,
        mediaId: String,
        trackId: String,
        startTimeMs: Long,
        durationMs: Long? = null
    ): Project {
        val media = project.mediaLibrary.find { it.id == mediaId }
            ?: return project

        val clipDuration = durationMs ?: media.durationMs
        val clip = TimelineClip(
            mediaId = mediaId,
            trackId = trackId,
            startTimeMs = startTimeMs,
            durationMs = clipDuration,
            sourceStartMs = 0L,
            sourceEndMs = media.durationMs
        )

        val newClips = project.clips + clip
        val newDuration = calculateProjectDuration(newClips)

        return project.copy(
            clips = newClips,
            durationMs = newDuration,
            updatedAt = System.currentTimeMillis()
        )
    }

    fun splitClip(project: Project, clipId: String, splitTimeMs: Long): Project {
        val clip = project.clips.find { it.id == clipId } ?: return project
        if (splitTimeMs <= clip.startTimeMs || splitTimeMs >= clip.endTimeMs) return project

        val relativeSplit = splitTimeMs - clip.startTimeMs
        val sourceSplit = clip.sourceStartMs + (relativeSplit * clip.speed).toLong()

        val left = clip.copy(
            id = UUID.randomUUID().toString(),
            durationMs = relativeSplit,
            sourceEndMs = sourceSplit
        )
        val right = clip.copy(
            id = UUID.randomUUID().toString(),
            startTimeMs = splitTimeMs,
            durationMs = clip.durationMs - relativeSplit,
            sourceStartMs = sourceSplit
        )

        val newClips = project.clips.filter { it.id != clipId } + left + right
        return project.copy(
            clips = newClips,
            updatedAt = System.currentTimeMillis()
        )
    }

    fun trimClip(
        project: Project,
        clipId: String,
        newStartMs: Long? = null,
        newEndMs: Long? = null
    ): Project {
        val clip = project.clips.find { it.id == clipId } ?: return project

        var start = newStartMs ?: clip.startTimeMs
        var end = newEndMs ?: clip.endTimeMs
        if (end <= start) return project

        val duration = end - start
        val sourceDeltaStart = ((start - clip.startTimeMs) * clip.speed).toLong()
        val newSourceStart = clip.sourceStartMs + sourceDeltaStart

        val updated = clip.copy(
            startTimeMs = start,
            durationMs = duration,
            sourceStartMs = newSourceStart.coerceAtLeast(0L)
        )

        val newClips = project.clips.map { if (it.id == clipId) updated else it }
        return project.copy(
            clips = newClips,
            durationMs = calculateProjectDuration(newClips),
            updatedAt = System.currentTimeMillis()
        )
    }

    fun moveClip(project: Project, clipId: String, newStartMs: Long, newTrackId: String? = null): Project {
        val clip = project.clips.find { it.id == clipId } ?: return project
        val updated = clip.copy(
            startTimeMs = newStartMs.coerceAtLeast(0L),
            trackId = newTrackId ?: clip.trackId
        )
        val newClips = project.clips.map { if (it.id == clipId) updated else it }
        return project.copy(
            clips = newClips,
            durationMs = calculateProjectDuration(newClips),
            updatedAt = System.currentTimeMillis()
        )
    }

    fun deleteClip(project: Project, clipId: String): Project {
        val newClips = project.clips.filter { it.id != clipId }
        return project.copy(
            clips = newClips,
            durationMs = calculateProjectDuration(newClips),
            updatedAt = System.currentTimeMillis()
        )
    }

    fun setClipSpeed(project: Project, clipId: String, speed: Float): Project {
        val safeSpeed = speed.coerceIn(0.1f, 10f)
        val clip = project.clips.find { it.id == clipId } ?: return project
        // Ajusta duração visual de acordo com a velocidade
        val originalSourceDuration = (clip.sourceEndMs ?: 0L) - clip.sourceStartMs
        val newDuration = (originalSourceDuration / safeSpeed).toLong()

        val updated = clip.copy(speed = safeSpeed, durationMs = newDuration)
        val newClips = project.clips.map { if (it.id == clipId) updated else it }
        return project.copy(
            clips = newClips,
            durationMs = calculateProjectDuration(newClips),
            updatedAt = System.currentTimeMillis()
        )
    }

    fun setClipVolume(project: Project, clipId: String, volume: Float): Project {
        val updated = project.clips.map {
            if (it.id == clipId) it.copy(volume = volume.coerceIn(0f, 2f)) else it
        }
        return project.copy(clips = updated, updatedAt = System.currentTimeMillis())
    }

    fun setClipOpacity(project: Project, clipId: String, opacity: Float): Project {
        val updated = project.clips.map {
            if (it.id == clipId) it.copy(opacity = opacity.coerceIn(0f, 1f)) else it
        }
        return project.copy(clips = updated, updatedAt = System.currentTimeMillis())
    }

    fun addTrack(project: Project, type: TrackType, name: String): Project {
        val order = project.tracks.maxOfOrNull { it.order }?.plus(1) ?: 0
        val track = TimelineTrack(
            type = type,
            name = name,
            order = order
        )
        return project.copy(
            tracks = project.tracks + track,
            updatedAt = System.currentTimeMillis()
        )
    }

    private fun calculateProjectDuration(clips: List<TimelineClip>): Long {
        return clips.maxOfOrNull { it.endTimeMs } ?: 0L
    }
}
