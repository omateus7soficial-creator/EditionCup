package com.editioncup.ui.screens.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.editioncup.ui.theme.BackgroundDark
import com.editioncup.ui.theme.PurplePrimary
import com.editioncup.ui.theme.SurfaceDark
import com.editioncup.ui.theme.SurfaceVariant

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    projectId: String,
    onBack: () -> Unit,
    onExport: () -> Unit
) {
    var isPlaying by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Editor") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                },
                actions = {
                    IconButton(onClick = { /* undo */ }) {
                        Icon(Icons.Default.Undo, contentDescription = "Desfazer")
                    }
                    IconButton(onClick = { /* redo */ }) {
                        Icon(Icons.Default.Redo, contentDescription = "Refazer")
                    }
                    TextButton(onClick = onExport) {
                        Text("Exportar", color = PurplePrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BackgroundDark)
            )
        },
        containerColor = BackgroundDark
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // ========== PREVIEW ==========
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.45f)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(SurfaceDark),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Pré-visualização\n(Media3 Player)",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyLarge
                )
            }

            // ========== CONTROLES DE PLAYBACK ==========
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { /* seek -5s */ }) {
                    Icon(Icons.Default.Replay5, contentDescription = "Voltar 5s")
                }
                IconButton(
                    onClick = { isPlaying = !isPlaying },
                    modifier = Modifier.size(56.dp)
                ) {
                    Icon(
                        if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pausar" else "Reproduzir",
                        modifier = Modifier.size(36.dp),
                        tint = PurplePrimary
                    )
                }
                IconButton(onClick = { /* seek +5s */ }) {
                    Icon(Icons.Default.Forward5, contentDescription = "Avançar 5s")
                }
            }

            // ========== TOOLBAR DE FERRAMENTAS ==========
            ScrollableTabRow(
                selectedTabIndex = 0,
                containerColor = SurfaceVariant,
                edgePadding = 8.dp
            ) {
                listOf("Cortar", "Velocidade", "Volume", "Texto", "Efeitos", "Áudio").forEachIndexed { index, title ->
                    Tab(
                        selected = index == 0,
                        onClick = { /* selecionar ferramenta */ },
                        text = { Text(title, style = MaterialTheme.typography.labelMedium) }
                    )
                }
            }

            // ========== TIMELINE ==========
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.4f)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(SurfaceDark)
            ) {
                Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
                    Text(
                        "Linha do tempo (multifaixa)",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Faixa de vídeo (placeholder)
                    TimelineTrackPlaceholder(
                        label = "V1",
                        color = androidx.compose.ui.graphics.Color(0xFF4A90D9)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    // Faixa de áudio
                    TimelineTrackPlaceholder(
                        label = "A1",
                        color = androidx.compose.ui.graphics.Color(0xFF50C878)
                    )
                }
            }
        }
    }
}

@Composable
private fun TimelineTrackPlaceholder(
    label: String,
    color: androidx.compose.ui.graphics.Color
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(28.dp)
        )
        Box(
            modifier = Modifier
                .weight(1f)
                .height(36.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(color.copy(alpha = 0.3f))
        )
    }
}
