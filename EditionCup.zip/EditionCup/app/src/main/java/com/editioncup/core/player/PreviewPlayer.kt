package com.editioncup.core.player

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import timber.log.Timber

/**
 * Wrapper simples do ExoPlayer para a pré-visualização do editor.
 * Em versões futuras será expandido para compor múltiplos clipes da timeline.
 */
class PreviewPlayer(context: Context) {

    private val player: ExoPlayer = ExoPlayer.Builder(context)
        .setHandleAudioBecomingNoisy(true)
        .build()
        .apply {
            playWhenReady = false
            repeatMode = Player.REPEAT_MODE_OFF
        }

    val exoPlayer: ExoPlayer get() = player

    fun setMedia(uri: String) {
        try {
            val mediaItem = MediaItem.fromUri(uri)
            player.setMediaItem(mediaItem)
            player.prepare()
            Timber.d("PreviewPlayer: mídia carregada – $uri")
        } catch (e: Exception) {
            Timber.e(e, "Falha ao carregar mídia no PreviewPlayer")
        }
    }

    fun play() = player.play()
    fun pause() = player.pause()
    fun seekTo(positionMs: Long) = player.seekTo(positionMs)
    fun isPlaying(): Boolean = player.isPlaying
    fun getCurrentPosition(): Long = player.currentPosition
    fun getDuration(): Long = player.duration.coerceAtLeast(0L)

    fun release() {
        player.release()
        Timber.d("PreviewPlayer liberado")
    }
}
